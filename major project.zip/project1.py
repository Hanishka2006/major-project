# Import necessary libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import joblib



#data preprocessing
data = pd.read_csv('D:/packages/stunt2.csv')
data.ffill(inplace=True)
data.fillna(data.mean(), inplace=True)


#displaying the first few rows of the data
print(data.head())

#displaying the summary information of the data
print(data.info())

#displaying the statistical summary of the data
print(data.describe())

#data exploration and visualization
sns.countplot(data['target'])
plt.show()
sns.countplot

#feature selection
corr = data.corr()
plt.figure(figsize=(15, 10))
sns.heatmap(corr, annot=True)
plt.show()

#splitting the data into features and target variable
X = data.drop('target', axis=1)
y = data['target']

#feature scaling
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)


#model building
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)
model = LogisticRegression()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)


#model evaluation
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy}")
print(f"Classification Report:\n{classification_report(y_test, y_pred)}")
print(f"Confusion Matrix:\n{confusion_matrix(y_test, y_pred)}")


#model interpretation
coefficients = model.coef_
intercept = model.intercept_
print(f"Coefficients: {coefficients}")
print(f"Intercept: {intercept}")

#developing the model
joblib.dump(model, 'heart_disease_model.pkl')
print("Model saved successfully!")


# Load the model
loaded_model = joblib.load('heart_disease_model.pkl')
print("Model loaded successfully!")


#model prediction
y_pred_loaded = loaded_model.predict(X_test)
accuracy_loaded = accuracy_score(y_test, y_pred_loaded)
print(f"Accuracy: {accuracy_loaded}")
print(f"Classification Report:\n{classification_report(y_test, y_pred_loaded)}")
print(f"Confusion Matrix:\n{confusion_matrix(y_test, y_pred_loaded)}")

